#!/bin/bash

echo 'who is barman'


flag="false"
while read line
do
    string=${line}
    array=(${string// /*})
    array=(${array//,/ })

    bool="false"
    for var in ${array[@]}
    do
        newVar=${var//\*/}
        if [ "$newVar" == 'barman' ] 
        then
            bool="true" 
        fi
    done

    if [ "$bool" == "true" ]
    then
        echo ${array[0]//\*/ }
        flag="true"
    fi
done < work.txt

if [ "$flag" == "false" ]
then
echo 'NONE'
fi
echo 'Who has at least 3 jobs'

index=0
list=[]
while read line
do
    string=${line}
    array=(${string// /*})
    array=(${array//,/ })

    if [[ ${#array[@]} -gt 5 ]]
    then
        echo ${array[0]//\*/}
    fi
done < work.txt

if [ "$flag" == "false" ]
then
echo 'NONE'
fi

echo 'Read in a job type and give how many people are in that position'

job=$1

num=0
while read line
do
    string=${line}
    array=(${string// /*})
    array=(${array//,/ })

    bool="false"
    for var in ${array[@]}
    do
        newVar=${var//\*/}
        if [ "$newVar" == "${job}" ] 
        then
            num=${num+1}
        fi
    done
done < work.txt
echo $num


