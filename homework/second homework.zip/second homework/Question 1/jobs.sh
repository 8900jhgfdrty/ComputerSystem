#!/bin/sh
awk 'BEGIN{FS=",";}{ if($3 == 0){flag=1; print $1;}} END{if(flag != 1) print "NONE"}' data.txt
awk 'BEGIN{FS=",";}{number=number+$4;} END{print number}' data.txt
maxplace=`awk 'BEGIN{FS=",";}{ if($3>maxplace){ maxplace=$3}} END{print maxplace}' data.txt`
max=$maxplace
awk 'BEGIN{FS=",";}{if($3==max){print $1,$2}}' data.txt
