﻿#$a="5"
#$b=6
#$a+$b

# Write a powershell script
#  that calculates the sum
# of the numbers for each
# and every line
#  the file is the first parameter


$file=Get-Content $args[0]

foreach ($i in $file)
{
    $numbersInLine=$i.split(" ")
    $sumInLine=0
    foreach ($k in $numbersInLine)
    {
        $sumInLine=$sumInLine+$k
        #$sumInLine+=$k
        #$sumInLine=[int]$k+$sumInLine
    }
    Write-Output "The sum of $i is: $sumInLine"
}