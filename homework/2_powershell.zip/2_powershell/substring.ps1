﻿# Write a powershell script
#  which gives you back the characters from 2 to 5 from each
# and every line
#  the file name is the first parameter

# e.g.: 
#  xbashxxxxxxxx
#  xkickxxxxxxxx
#  cut

$file=Get-Content $args[0]

#for(from;to;incrementing)
for ($i=0;$i -lt $file.Length;$i=$i+1)
{
    if($file[$i].Length -lt 5)
    {
        $file[$i]
    }else
    {
        $file[$i].Substring(1,4)
    }
    
}