﻿# Write a powershell script, that writes out the second word from each line from
#  a given file

# e.g.: data.txt looks like:
#  apple orange cherry banana
#  one two three four
#  comsys opsys ops
#  me you

#output:
#   orange
#   two
#   opsys
#   you

$file=Get-Content $args[0]
foreach ($i in $file)
{
    $i.split(" ")[1]
}