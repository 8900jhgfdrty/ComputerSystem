﻿<# Write a powershell script
 that sums the numbers
 the numbers are input from the terminal
 we ask for numbers, until the user give "end" keyword
#>

$a=0
$sum=0
while ($a -ne "end")
{
    $sum+=$a
    $a=Read-Host "Give me a number"
}

Write-Output "The sum of the numbers: $sum"

