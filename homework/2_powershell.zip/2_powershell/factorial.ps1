﻿#Implement a PowerShell script which counts the factorial value
# of a given number N (N!)! 
# The number is given by a parameter!
# Check whether there is a parameter or not!

if ($args.Length -eq 0) {
    Write-Output "Give me a parameter"
    exit 1
}

$fact=1
for ($i=1;$i -le $args[0];$i++)
{
    $fact*=$i
}

Write-Output "The factorial of $($args[0]): $fact"