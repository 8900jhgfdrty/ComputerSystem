﻿#Create a PowerShell script which decide whether
#  a number is a prime number or not!
# The number is a parameter, but ask for it if not defined


if ($args.Length -ne 0)
{
    $number=$args[0]
}
else
{
    $number=Read-Host "Give me a number"
}

$found=$false
for ($i=2;$i -lt [Math]::Sqrt($number);$i++)
{
    if ($number % $i -eq 0)
    {
        Write-Output "Foud one: $i"
        $found=$true
    }
}

if($found)
{
    Write-Output "Not a prime"

}
else
{
    Write-Output "It is a prime"
}