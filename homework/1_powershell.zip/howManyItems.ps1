﻿# Write a shell script that writes out how many items
#  we have in the given directory
#    The directory is the first parameter

(Get-ChildItem $args[0]).Length