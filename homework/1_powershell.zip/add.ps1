﻿# Write a shell script that writes out the sum of the first and second parameter

# Shell script solution: expr $1 + $2

$args[0] + $args[1]