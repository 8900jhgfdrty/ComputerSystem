﻿# Write a shell script that writes out all the items from the current directry
# that size is bigegr than the given number (given means first parameter)

# We need to use a new filet: where-object
$maxLength=$args[0]

Get-ChildItem | Where-Object -Property Length -gt $maxLength