﻿# Write a shell script, that expects a file name as a parameter
# In the file, there are numbers (1 number/1 line)
# The script should write out the biggest number

(Get-Content $args[0] | Measure-Object -Maximum).Maximum