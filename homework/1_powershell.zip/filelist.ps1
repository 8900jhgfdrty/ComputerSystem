﻿# Write a shell script, that writes out the file in the current directory
#   Only files should be listed (no directories)
Get-ChildItem -File