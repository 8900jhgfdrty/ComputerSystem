﻿$file= Get-Content $args
$bool=$false
foreach($i in $file){
$place=$i.split(",")
[int]$number=$i.split(",")[3]
$sumnumber+=$number
if([int]$place[2] -eq 0){
$workplace=$i.split(",")[1]
$bool=$true
if($bool){
 Write-Output "$workplace"
 }
}
}
    if($bool=$false){
    Write-Output "NONE"
    }
Write-Output "security guards number:$sumnumber"
$biggest=0
foreach($i in $file){
[int]$max=$i.split(",")[2]
if($max -gt $biggest){
$biggest=$max
}
}
foreach($i in $file){
if($biggest -eq $max){
$name=$i.Split(",")[0]
$place1=$i.Split(",")[1]
}
}
Write-Output "$name,$place1"

